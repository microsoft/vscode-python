#-------------------------------------------------------------------------------
# Name:        PowerCenterCacheFileWatcher
# Purpose:
#
# Author:      Maciej Grabowski
#
# Created:     04-11-2011
# Copyright:   (c) maciejg 2011
# Licence:     GPL
#-------------------------------------------------------------------------------
import ConfigParser

import os, time

from os.path import join, getsize

config = ConfigParser.SafeConfigParser()

config.read('PowerCenterCacheFileWatcher.cfg')

TempDirName = config.get('PCCF_config', 'TempDirName')
CacheDirName = config.get('PCCF_config', 'CacheDirName')
threshold_KB = config.getint('PCCF_config', 'threshold_KB')
CacheFilesListFileName = config.get('Common', 'CacheFilesListFileName')

cacheDir=join(os.curdir,CacheDirName)
tempDir=join(os.curdir,TempDirName)

fileSizes=[]
fileNames=[]

dirList=[cacheDir, tempDir]

while True:
    try:
        watchTime = int(raw_input("Please provide watching time (minutes): "))
        break
    except ValueError:
        print "Oops!  That was no valid number.  Try again..."

#watchTime=30*60 #seconds
watchTime=watchTime*60 #seconds
threshold=threshold_KB*2**10 #bytes

watchStartTime = time.time()
#time.ctime(os.path.getmtime(file))

breakLoop=False

def updateFileSizes(fName, fSize):
    for i in range(len(fileSizes)):
        if fileSizes[i][0]==fName:
            if fileSizes[i][1]<fSize:
                fileSizes[i]=(fName,fSize)

def createReport():
    fileHandle = open ( CacheFilesListFileName, 'w' )
    for i in fileSizes:
        fileHandle.write( i[0] + ' : ' + str(i[1])+'\n' )
    fileHandle.close()

for i in range (watchTime):
    if i%60==0:
        print 'After ' + str(i/60) + ' minutes collected ' + str(len(fileSizes))+' files.'
        print str((watchTime - i)/60) + ' minutes remaining.'
        createReport()

    for myDir in dirList:
        for myFile in os.listdir(myDir):
            try:
                fileModTime=os.path.getctime(join(myDir,myFile))
            except:
                fileModTime=0
            try:
                size=getsize(join (myDir,myFile))
            except:
                size=0
            if fileModTime>watchStartTime:
                if size>threshold:
                    if myFile not in fileNames:
                        fileNames+=[myFile]
                        fileSizes+=[(myFile, size)]
                        #fileSizes+=[(myFile, size, fileModTime)]
                    else:
                        updateFileSizes(myFile,size)
    if i<watchTime:time.sleep(1)



createReport()

print 'TOTAL:',len(fileSizes),'files'
print 'Starded at:',watchStartTime, '(', time.ctime(watchStartTime), ')'
print 'Finished at at:',time.time(), '(', time.ctime(time.time()), ')'

