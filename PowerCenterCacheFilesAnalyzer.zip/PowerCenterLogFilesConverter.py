#-------------------------------------------------------------------------------
# Name:        PowerCenterLogFilesConverter
# Purpose:
#
# Author:      Maciej Grabowski
#
# Created:     04-11-2011
# Copyright:   (c) maciejg 2011
# Licence:     GPL
#-------------------------------------------------------------------------------
from __future__ import with_statement

import os, time
import fileinput
from subprocess import call

from os.path import join, getsize

import ConfigParser

config = ConfigParser.SafeConfigParser()

config.read('PowerCenterCacheFileWatcher.cfg')

sessLogSrcDirPath = config.get('Common', 'sessLogSrcDirPath')
sessLogTgtDirPath = config.get('Common', 'sessLogTgtDirPath')
infacmdPath = config.get('PCLFC_config', 'infacmdPath')
CacheFilesListFileName = config.get('Common', 'CacheFilesListFileName')


cacheFileList=[]

with open(CacheFilesListFileName, "r") as repFile:
    for repFileLine in repFile:
        cacheFileList+=[(repFileLine[:repFileLine.index(":")-1],repFileLine[repFileLine.index(":")+2:])]
stmt=''
for myFile in os.listdir(sessLogSrcDirPath):
    with open(join(sessLogSrcDirPath,myFile), "r") as f:
        outFileName=join(sessLogTgtDirPath,myFile)
        outFileName=outFileName.replace('log.bin','txt')
        #print outFileName
        if f.name[-3:]=='bin':
            stmt=infacmdPath+' ConvertLogFile -in '+f.name+' -fm Text -lo '+outFileName
            print stmt
            call(stmt)




