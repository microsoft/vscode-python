#-------------------------------------------------------------------------------
# Name:        PowerCenterLogFilesAnalyzer
# Purpose:
#
# Author:      Maciej Grabowski
#
# Created:     04-11-2011
# Copyright:   (c) maciejg 2011
# Licence:     GPL
#-------------------------------------------------------------------------------
from __future__ import with_statement

import os, time
import fileinput
import ConfigParser

from os.path import join, getsize

config = ConfigParser.SafeConfigParser()

config.read('PowerCenterCacheFileWatcher.cfg')

sessLogTgtDirPath = config.get('Common', 'sessLogTgtDirPath')
repFileName = config.get('Common', 'repFileName')
CacheFilesListFileName = config.get('Common', 'CacheFilesListFileName')

cacheFileList=[]

with open(CacheFilesListFileName, "r") as fileList:
    for logFileLine in fileList:
        cacheFileList+=[(logFileLine[:logFileLine.index(":")-1],logFileLine[logFileLine.index(":")+2:])]

FileErrLog=[]

print sessLogTgtDirPath


def printCurrLog(repFile):
    for logLine in FileErrLog:
        #print i
        repFile.write( logLine )


repFile = open ( repFileName, 'w' )

for myFile in os.listdir(sessLogTgtDirPath):
    if myFile[-4:]=='.txt':
        with open(join(sessLogTgtDirPath,myFile), "r") as f:
            #print f.name
            FileErrLog=['==================================================\n']
            FileErrLog+=[f.name+'\n']
            #SORTERS - genereal search
            for line in f:
                if '-pass' in line:
                    #print line
                    FileErrLog+=[line]
            #Line by line search for files
                for cacheFile in cacheFileList:
                    cacheFileName=cacheFile[0][:-1]
                    cacheFileSize=cacheFile[1]
                    aggFileFound=0
                    if cacheFileName[:-4] in line:
                        if cacheFileName[-3:] == "idx":
                            cachePourpose='index'
                        elif cacheFileName[-3:] == "dat":
                            cachePourpose='data'
                        else: cachePourpose=cacheFileName[-3:]

                        #AGGREGATORS
                        if 'AGG' in cacheFileName and '[AGG' in line:
                            FileErrLog+=[cacheFileName+": Created " + str(cacheFileSize[:-1]) + " bytes (~"+str(int(cacheFileSize)/1024**2)+ " MB) cache for "+line[line.rfind("["):-2]+'.\n']
                            aggFileFound=1

                        #JOINERS
                        elif 'JNR' in cacheFileName and 'Created' in line:
                            FileErrLog+=[" Created " + str(cacheFileSize[:-1]) + " bytes (~"+str(int(cacheFileSize)/1024**2)+ " MB) cache for " + line[line.rfind("["):-2]+' '+cachePourpose+'.\n']

                        #LOOKUPS
                        elif 'LKUP' in cacheFileName and 'Created' in line:
                            print cacheFileName
                            FileErrLog+=[" Created " + str(cacheFileSize[:-1]) + " bytes (~"+str(int(cacheFileSize)/1024**2)+ " MB) cache for " + line[line.rfind("["):-2]+' '+cachePourpose+'.\n']

                    if aggFileFound==1:break
                    #if 'Created' in line and cacheFile[0][:-5] in line:
                        #print "Session"+ f.name[f.name.rfind("\\")+1:] + "created" + str(cacheFile[1]) + "bytes ("+str(int(cacheFile[1])/1024**2)+ "MB)cache for" + line[line.rfind("["):]+'for'+cachePourpose+'.'



        if len(FileErrLog)>2:printCurrLog(repFile)

print "Searched for "+ str(len(cacheFileList)) + " files in Session Logs"
repFile.close()